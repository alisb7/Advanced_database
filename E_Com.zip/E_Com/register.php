<?php
include('includes/db.php');

$username = $email = $pass = $confirm = '';
$user_type = ''; // User type will be selected by the user
$flag_form = $flag_pass = $flag_user = false;

if (isset($_POST['submit'])) {
    // Validate form fields
    if ($_POST['username'] == '' || $_POST['email'] == '' || $_POST['pass'] == '' || $_POST['confirm'] == '' || $_POST['user_type'] == '') {
        $flag_form = true;
    } else {
        // Assign input values
        $username = $_POST['username'];
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $confirm = $_POST['confirm'];
        $user_type = $_POST['user_type']; // Get user type

        // Check password match
        if ($pass != $confirm) {
            $flag_pass = true;
        } else {
            // Check if user already exists
            $get_user = "SELECT * FROM user WHERE Email='$email'";
            $run_user = mysqli_query($con, $get_user);
            $count = mysqli_num_rows($run_user);

            if ($count != 0) {
                $flag_user = true;
            } else {
                // Hash the password
                $hashed_pass = password_hash($pass, PASSWORD_DEFAULT);
                
                // Insert new user into the database
                $insert = "INSERT INTO user (UserName, Email, Password, UserType) VALUES ('$username', '$email', '$hashed_pass', '$user_type')";
                $run_insert = mysqli_query($con, $insert);

                if ($run_insert) {
                    header('Location: login.php');
                    exit();
                } else {
                    echo '<h1 class="title text-warning">Registration failed. Please try again.</h1>';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html dir="ltr">
<head>
<meta charset="UTF-8" />
<meta name="format-detection" content="telephone=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="image/favicon.png" rel="icon" />
<title>Register</title>
<meta name="description" content="Responsive and clean HTML template design for any kind of eCommerce webshop">
<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
<link rel="stylesheet" type="text/css" href="css/responsive.css" />
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans' type='text/css'>
<style>
    body, h4, p {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
    .price {
        font-family: 'Open Sans', sans-serif !important; /* Ensures price uses default font */
    }
</style>
<!-- CSS Part End-->
</head>
<body>
<div class="wrapper-wide">
  <div id="header">
    <!-- Top Bar Start-->
    <?php include('includes/header.php'); ?>
    <!-- Main Content End-->
  </div>
  <div id="container">
    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-home"></i></a></li>
        <li><a href="login.php">Account</a></li>
        <li><a href="register.php">Register</a></li>
      </ul>
      <!-- Breadcrumb End-->
      <div class="row">
        <!-- Middle Part Start -->
        <div class="col-sm-9" id="content">
          <h1 class="title">Account Registration</h1>
          <?php
            if ($flag_form) {
                echo('<h1 class="title text-warning">Please fill in all required information</h1>');
            }
            if ($flag_pass) {
                echo('<h1 class="title text-warning">Passwords do not match</h1>');
            }
            if ($flag_user) {
                echo('<h1 class="title text-warning">You are already registered</h1>');
            }
          ?>
          <p>If you already have an account, please go to the <a href="login.php">login page</a>.</p>
          <form class="form-horizontal" method="POST">
            <fieldset id="account">
              <legend>Your Personal Information</legend>
              <div class="form-group required">
                <label for="input-username" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="input-username" placeholder="Username" name="username">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-email" class="col-sm-2 control-label">Email Address</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="input-email" placeholder="Email Address" name="email">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-user-type" class="col-sm-2 control-label">User Type</label>
                <div class="col-sm-10">
                  <select class="form-control" id="input-user-type" name="user_type">
                    <option value="">Select User Type</option>
                    <option value="customer">Customer</option>
                    <option value="seller">Seller</option>
                  </select>
                </div>
              </div>
            </fieldset>
            <fieldset>
              <legend>Your Password</legend>
              <div class="form-group required">
                <label for="input-password" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" id="input-password" placeholder="Password" name="pass">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-confirm" class="col-sm-2 control-label">Confirm Password</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" id="input-confirm" placeholder="Confirm Password" name="confirm">
                </div>
              </div>
            </fieldset>
            <div class="buttons">
              <div class="pull-right">
                <input type="submit" class="btn btn-primary" value="Register" name='submit' id='submit'>
              </div>
            </div>
          </form>
        </div>
        <!-- Middle Part End -->
      </div>
    </div>
  </div>
  <!-- Footer Start -->
  <?php include('includes/footer.php'); ?>
  <!-- Footer End -->
</div>
<!-- JS Part Start-->
<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.easing-1.3.min.js"></script>
<script type="text/javascript" src="js/jquery.dcjqaccordion.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
<!-- JS Part End-->
</body>
</html>
