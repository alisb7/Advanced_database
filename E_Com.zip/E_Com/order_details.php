<?php
session_start();
include('includes/db.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: register.php');
    exit();
}

// Get the order ID from the URL
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch order details from the database
$stmt = $con->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
$stmt->execute();
$order_result = $stmt->get_result();

// Check if the order exists
if ($order_result->num_rows === 0) {
    echo "<h1>Order Not Found</h1>";
    exit();
}

// Fetch the order details
$order = $order_result->fetch_assoc();
?>

<!DOCTYPE html>
<html dir="ltr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Order Details</title>
    <link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
</head>
<body>
<div class="wrapper-wide">
    <div id="header">
        <?php include('includes/header.php'); ?>
    </div>
    <div id="container">
        <div class="container">
            <h1 class="title">Order Details</h1>
            <table class="table table-bordered">
                <tr>
                    <th>Order ID</th>
                    <td><?php echo htmlspecialchars($order['id']); ?></td>
                </tr>
                <tr>
                    <th>Order Date</th>
                    <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                </tr>
                <tr>
                    <th>Total Amount</th>
                    <td><?php echo number_format($order['total_amount'], 2) . " AUD"; ?></td>
                </tr>
                <tr>
                    <th>Status</th>
                    <td><?php echo htmlspecialchars($order['status']); ?></td>
                </tr>
                <tr>
                    <th>Items</th>
                    <td>
                        <ul>
                            <?php
                            // Fetch items for this order with product details
                            $items_stmt = $con->prepare("
                                SELECT oi.quantity, oi.price, p.name
                                FROM order_details oi
                                JOIN pro p ON oi.product_id = p.id
                                WHERE oi.order_id = ?
                            ");
                            if ($items_stmt === false) {
                                die('MySQL prepare() failed: ' . htmlspecialchars($con->error));
                            }
                            $items_stmt->bind_param("i", $order_id);
                            $items_stmt->execute();
                            $items_result = $items_stmt->get_result();

                            if ($items_result->num_rows > 0) {
                                while ($item = $items_result->fetch_assoc()) {
                                    echo "<li>" . htmlspecialchars($item['name']) . " (x" . htmlspecialchars($item['quantity']) . ") - " . number_format($item['price'], 2) . " AUD</li>";
                                }
                            } else {
                                echo "<li>No items found for this order.</li>";
                            }

                            // Close the items statement
                            $items_stmt->close();
                            ?>
                        </ul>
                    </td>
                </tr>
            </table>
            <a href="order.php" class="btn btn-primary">Back to My Orders</a>
        </div>
    </div>
    <footer id="footer">
        <?php include('includes/footer.php'); ?>
    </footer>
</div>
<script src="js/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the order statement
$stmt->close();
?>
