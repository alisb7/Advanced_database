<?php
include('includes/db.php');
if(!isset($_SESSION['email'])){
    header('Location: index.php');
}
$email = $_SESSION['email'];
$get_u = "SELECT * FROM user WHERE email='$email'";
$run_u = mysqli_query($con, $get_u);
$row_u = mysqli_fetch_array($run_u);
$name_u = $row_u['name'];
$pass = $row_u['pass'];
$address = $row_u['address'];
$postal = $row_u['postal'];
$phone = $row_u['phone'];
$flag_form = $flag_pass = $flag_user = false;

if(isset($_POST['submit'])){
  if($_POST['name'] == '' || $_POST['email'] == '' || $_POST['phone'] == '' || $_POST['address'] == '' || $_POST['postal'] == ''){
    $flag_form = true;
  }else{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $postal = $_POST['postal'];
    $old_pass = $_POST['old_pass'];
    
    if($old_pass == ''){
      $update = "UPDATE user SET name='$name', email='$email', phone='$phone', address='$address', postal='$postal' WHERE email='$email'";
      $run_update = mysqli_query($con, $update);
      if($run_update){
        $flag_user = true;
      }
    }else{
      if(md5($old_pass) == $pass){
        $new_pass = $_POST['pass'];
        $confirm = $_POST['confirm'];
        if($new_pass == $confirm){
          $new_pass = md5($new_pass);
          $update = "UPDATE user SET name='$name', email='$email', phone='$phone', address='$address', postal='$postal', pass='$new_pass' WHERE email='$email'";
          $run_update = mysqli_query($con, $update);
          if($run_update){
            $flag_user = true;
          }
        }
      }
    }
  }
}
?>
<!DOCTYPE html>
<html dir="rtl">
<head>
<meta charset="UTF-8"/>
<meta name="format-detection" content="telephone=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="image/favicon.png" rel="icon" />
<title>Mobile Online Store</title>
<meta name="description" content="Responsive and clean HTML template design for any kind of ecommerce webshop">
<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap-rtl.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
<link rel="stylesheet" type="text/css" href="css/responsive.css" />
<link rel="stylesheet" type="text/css" href="css/stylesheet-rtl.css" />
<link rel="stylesheet" type="text/css" href="css/responsive-rtl.css" />
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans' type='text/css'>
<!-- CSS Part End-->
</head>
<body>
<div class="wrapper-wide">
  <div id="header">
    <!-- Top Bar Start-->
      <?php include('includes/header.php'); ?>
    <!-- Main Menu End-->
  </div>
  <div id="container">
    <div class="container">
      <div class="row">
        <!-- Left Part Start-->
        <aside id="column-left" class="col-sm-3 hidden-xs">
          <?php include('includes/aside.php'); ?>
        </aside>
        <!-- Left Part End-->
        <!--Middle Part Start-->
        <div class="col-sm-9" id="content">
          <h1 class="title">Edit Account Information</h1>
          <?php
            if($flag_form){
              echo('<h1 class="title text-warning">Please complete the requested information</h1>');
            }
            if($flag_pass){
              echo('<h1 class="title text-warning">Passwords do not match</h1>');
            }
            if($flag_user){
              echo('<h1 class="title text-warning">Information updated successfully</h1>');
            }
          ?>
          <form class="form-horizontal" method="POST">
            <fieldset id="account">
              <legend>Your Personal Information</legend>
              <div class="form-group required">
                <label for="input-firstname" class="col-sm-2 control-label">Name</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="input-firstname" placeholder="Name" value="<?php echo($name_u); ?>" name="name">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-email" class="col-sm-2 control-label">Email Address</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="input-email" placeholder="Email Address" value="<?php echo($email); ?>" name="email">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-telephone" class="col-sm-2 control-label">Phone Number</label>
                <div class="col-sm-10">
                  <input type="tel" class="form-control" id="input-telephone" placeholder="Phone Number" value="<?php echo($phone); ?>" name="phone">
                </div>
              </div>
            </fieldset>
            <fieldset id="address">
              <legend>Address</legend>
              <div class="form-group required">
                <label for="input-address-1" class="col-sm-2 control-label">Address</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="input-address-1" placeholder="Address" value="<?php echo($address); ?>" name="address">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-postcode" class="col-sm-2 control-label">Postal Code</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="input-postcode" placeholder="Postal Code" value="<?php echo($postal); ?>" name="postal">
                </div>
              </div>
            </fieldset>
            <fieldset>
              <h2 class="title text-warning">If you are not changing your password, leave the fields below empty</h2>
              <legend>Your Password</legend>
              <div class="form-group required">
                <label for="input-password" class="col-sm-2 control-label">Old Password</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" id="input-password" placeholder="Old Password" name="old_pass">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-password" class="col-sm-2 control-label">New Password</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" id="input-password" placeholder="New Password" name="pass">
                </div>
              </div>
              <div class="form-group required">
                <label for="input-confirm" class="col-sm-2 control-label">Confirm New Password</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" id="input-confirm" placeholder="Confirm New Password" name="confirm">
                </div>
              </div>
            </fieldset>
            <div class="buttons">
              <div class="pull-right">
                <input type="submit" class="btn btn-primary" value="Update" name='submit' id='submit'>
              </div>
            </div>
          </form>
          <div class="col-sm-9" id="content">
            <h1 class="title">Your Orders</h1>
            <table class="table table-bordered table-responsive">
              <thead>
                <tr>
                  <td><strong>Name</strong></td>
                  <td><strong>Image</strong></td>
                  <td><strong>Quantity</strong></td>
                  <td><strong>Price</strong></td>
                  <td><strong>Order Date</strong></td>
                  <td><strong>Shipping Status</strong></td>
                </tr>
              </thead>
              <tbody>
                <?php
                $get_cart = "SELECT * FROM cart WHERE user_email='$email' ORDER BY send_status";
                $run_cart = mysqli_query($con, $get_cart);
                while($row_cart = mysqli_fetch_array($run_cart)){
                  $pro_id = $row_cart['pro_id'];
                  $count = $row_cart['count'];
                  $date = $row_cart['date'];
                  $status = $row_cart['send_status'];
                  #
                  $get_pro = "SELECT * FROM pro WHERE id=$pro_id";
                  $run_pro = mysqli_query($con, $get_pro);
                  $row_pro = mysqli_fetch_array($run_pro);
                  $name = $row_pro['name'];
                  $img = $row_pro['img'];
                  $price = $row_pro['price'];
                  echo("<tr>
                    <td>$name</td>
                    <td><img src='$img' width='60px'></td>
                    <td>$count</td>
                    <td>$price</td>
                    <td>$date</td>
                    <td>$status</td>
                  </tr>");
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
        <!--Middle Part End-->
      </div>
    </div>
  </div>
</div>
<!-- JS Part Start-->
<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.easing-1.3.min.js"></script>
<script type="text/javascript" src="js/jquery.dcjqaccordion.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
<!-- JS Part End-->
</body>
</html>
