<?php
// Start session and include database connection
session_start();
include('includes/db.php');

// Get category name from URL
$cat = $_GET['cat'];

// Prepare SQL statement to prevent SQL injection
$stmt = $con->prepare("SELECT * FROM cat WHERE name = ?");
$stmt->bind_param("s", $cat);
$stmt->execute();
$result = $stmt->get_result();
$row_cat = $result->fetch_assoc();
$cat_id = $row_cat['id'];

// Get products in the category
$stmt = $con->prepare("SELECT * FROM pro WHERE cat_id = ?");
$stmt->bind_param("i", $cat_id);
$stmt->execute();
$products = $stmt->get_result();
?>

<!DOCTYPE html>
<html dir="ltr">
<head>
<meta charset="UTF-8" />
<meta name="format-detection" content="telephone=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="image/favicon.png" rel="icon" />
<title><?php echo htmlspecialchars($cat); ?></title>
<meta name="description" content="Responsive and clean HTML template design for any kind of eCommerce webshop">
<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
<link rel="stylesheet" type="text/css" href="css/responsive.css" />
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans' type='text/css'>
<style>
    body, h4, p, .price {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
</style>
<!-- CSS Part End-->
</head>
<body>
<div class="wrapper-wide">
  <div id="header">
    <?php include('includes/header.php'); ?>
  </div>
  <div id="container">
    <div class="container">
      <ul class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-home"></i></a></li>
        <li><a href="cat.php?cat=<?php echo urlencode($cat); ?>"><?php echo htmlspecialchars($cat); ?></a></li>
      </ul>
      <div class="row">
        <aside id="column-left" class="col-sm-3 hidden-xs">
          <?php include('includes/aside.php'); ?>
        </aside>
        <div id="content" class="col-sm-9">
          <h1 class="title"><?php echo htmlspecialchars($cat); ?></h1>
          <div class="product-filter">
            <div class="row">
              <div class="col-md-4 col-sm-5">
                <div class="btn-group">
                  <button type="button" id="list-view" class="btn btn-default" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
                  <button type="button" id="grid-view" class="btn btn-default" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
                </div>
              </div>
            </div>
          </div>
          <br />
          <div class="row products-category">
            <?php while ($row_pro = $products->fetch_assoc()) { 
              $id = $row_pro['id'];
              $img = $row_pro['img'];
              $name = $row_pro['name'];
              $price = $row_pro['price']; ?>

              <div class="product-layout product-list col-xs-12">
                <div class="product-thumb">
                  <div class="image"><a href="pro.php?id=<?php echo $id; ?>"><img src="img/product/<?php echo htmlspecialchars($img); ?>" class="img-responsive" /></a></div>
                  <div>
                    <div class="caption">
                      <h4><a href="pro.php?id=<?php echo $id; ?>"><?php echo htmlspecialchars($name); ?> </a></h4>
                      <p class="price"><?php echo number_format($price, 2); ?> AUD</p>
                    </div>
                    <div class="button-group">
                      <form method="POST" action="func/add_cart.php">
                        <input type="hidden" name='id' value='<?php echo $id; ?>'>
                        <input class="btn-primary" type="submit" name='submit' value="Add to Cart" />
                      </form>
                      <div class="add-to-links">
                        <a href="func/add_compare.php?id=<?php echo $id; ?>"><i class="fa fa-exchange"></i></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php include('includes/footer.php'); ?>
</div>
<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.easing-1.3.min.js"></script>
<script type="text/javascript
