<?php
// config.php

// Override locale settings to force using Western numerals
setlocale(LC_ALL, 'en_US.UTF-8');
setlocale(LC_CTYPE, 'en_US.UTF-8');
setlocale(LC_NUMERIC, 'en_US.UTF-8');

// Force standard output encoding
header('Content-Type: text/html; charset=UTF-8');

// Set error reporting to display all errors and notices
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Custom error handler to ensure errors are displayed in Western numerals
set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    // Display error message with line numbers in Western numerals
    echo sprintf("<b>Error [%d]:</b> %s in <b>%s</b> on line <b>%d</b><br>", $errno, $errstr, $errfile, $errline);
    return true;
});

// Default timezone to avoid timezone-related warnings
date_default_timezone_set('UTC');
