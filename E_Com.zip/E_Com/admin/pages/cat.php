<?php
require_once 'config.php';
?>
<style>
    body, h4, p {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
    .price {
        font-family: 'Open Sans', sans-serif !important; /* Ensures price uses default font */
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Brands</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Brands</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Brand List</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $get = "SELECT * FROM cat";
                $run = mysqli_query($con, $get);
                while($row = mysqli_fetch_array($run)){
                    $id = $row['id'];
                    $name = $row['name'];
                ?>
                <tr>
                    <td><?php echo($name); ?></td>
                    <td><a class="btn btn-primary" href="index.php?cat_edit&id=<?php echo($id); ?>">Edit</a></td>
                    <td><a class="btn btn-warning" href="index.php?cat_del&id=<?php echo($id); ?>">Delete</a></td>
                </tr>

                <?php } ?>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
// Function to convert Persian numbers to English
function convertPersianNumbersToEnglish() {
    // Mapping Persian numbers to English numbers
    const persianToEnglishMap = {
        '۰': '0',
        '۱': '1',
        '۲': '2',
        '۳': '3',
        '۴': '4',
        '۵': '5',
        '۶': '6',
        '۷': '7',
        '۸': '8',
        '۹': '9'
    };

    // Convert numbers in the document
    document.body.innerHTML = document.body.innerHTML.replace(/[۰-۹]/g, function(match) {
        return persianToEnglishMap[match];
    });
}

// Run the conversion function on page load
window.onload = convertPersianNumbersToEnglish;
</script>
