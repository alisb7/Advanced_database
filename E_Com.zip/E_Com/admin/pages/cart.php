<?php
require_once 'config.php';
?>
<style>
    body, h4, p {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
    .price {
        font-family: 'Open Sans', sans-serif !important; /* Ensures price uses default font */
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Orders</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Orders</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Order List</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Date</th>
                  <th>Shipping Status</th>
                  <th>View</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $query = "SELECT * FROM cart WHERE status='1' GROUP BY user_email ORDER BY send_status";
                $result = mysqli_query($con, $query);

                if ($result) {
                    while ($row = mysqli_fetch_array($result)) {
                        $email = htmlspecialchars($row['user_email']);
                        $date = htmlspecialchars($row['date']);
                        $send_status = htmlspecialchars($row['send_status']);

                        // Fetch user details based on email
                        $get_user = "SELECT * FROM user WHERE email='$email'";
                        $run_user = mysqli_query($con, $get_user);

                        if ($run_user && mysqli_num_rows($run_user) > 0) {
                            $row_user = mysqli_fetch_array($run_user);
                            $name = htmlspecialchars($row_user['name']);
                        } else {
                            $name = 'Unknown User'; // Default if user not found
                        }
                ?>
                <tr>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $email; ?></td>
                    <td><?php echo $date; ?></td>
                    <td><?php echo ($send_status == '0') ? 'Pending' : 'Shipped'; ?></td>
                    <td><a class="btn btn-primary" href="index.php?show&email=<?php echo $email; ?>">View</a></td>
                </tr>

                <?php 
                    }
                } else {
                    echo '<tr><td colspan="5" class="text-center">No orders found.</td></tr>'; // Handle no orders case
                }
                ?>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<script>
// Function to convert Persian numbers to English
function convertPersianNumbersToEnglish() {
    // Mapping Persian numbers to English numbers
    const persianToEnglishMap = {
        '۰': '0',
        '۱': '1',
        '۲': '2',
        '۳': '3',
        '۴': '4',
        '۵': '5',
        '۶': '6',
        '۷': '7',
        '۸': '8',
        '۹': '9'
    };

    // Convert numbers in the document
    document.body.innerHTML = document.body.innerHTML.replace(/[۰-۹]/g, function(match) {
        return persianToEnglishMap[match];
    });
}

// Run the conversion function on page load
window.onload = convertPersianNumbersToEnglish;
</script>
