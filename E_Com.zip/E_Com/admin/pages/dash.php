<?php
require_once 'config.php';
// Database connection (assuming $con is the connection object)

// Utility function to convert Persian/Arabic digits to English
function convertToEnglishDigits($input) {
    $persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($persianDigits, $englishDigits, $input);
}

// Query to get total number of users
$get_user = "SELECT COUNT(*) as user_count FROM user";
$run_user = mysqli_query($con, $get_user);
$row_user = mysqli_fetch_array($run_user);
$count_user = convertToEnglishDigits($row_user['user_count']);

// Query to get total number of products
$get_pro = "SELECT COUNT(*) as pro_count FROM pro";
$run_pro = mysqli_query($con, $get_pro);
$row_pro = mysqli_fetch_array($run_pro);
$count_pro = convertToEnglishDigits($row_pro['pro_count']);

// Query to count the number of unregistered user carts
$get_uncart = "SELECT COUNT(DISTINCT ip) as uncart_count FROM uncart";
$run_uncart = mysqli_query($con, $get_uncart);
$row_uncart = mysqli_fetch_array($run_uncart);
$count_uncart = convertToEnglishDigits($row_uncart['uncart_count']);

// Query to count the number of unpaid carts (status = 0)
$get_cart_nostatus = "SELECT COUNT(DISTINCT user_email) as nostatus_count FROM cart WHERE status='0'";
$run_cart_nostatus = mysqli_query($con, $get_cart_nostatus);
$row_cart_nostatus = mysqli_fetch_array($run_cart_nostatus);
$count_cart_nostatus = convertToEnglishDigits($row_cart_nostatus['nostatus_count']);

// Query to count carts awaiting shipment (status = 1, send_status = 0)
$get_cart_unsend = "SELECT COUNT(DISTINCT user_email) as unsend_count FROM cart WHERE status='1' AND send_status='0'";
$run_cart_unsend = mysqli_query($con, $get_cart_unsend);
$row_cart_unsend = mysqli_fetch_array($run_cart_unsend);
$count_cart_unsend = convertToEnglishDigits($row_cart_unsend['unsend_count']);

// Query to count shipped carts (status = 1, send_status = 1)
$get_cart_send = "SELECT COUNT(DISTINCT user_email) as send_count FROM cart WHERE status='1' AND send_status='1'";
$run_cart_send = mysqli_query($con, $get_cart_send);
$row_cart_send = mysqli_fetch_array($run_cart_send);
$count_cart_send = convertToEnglishDigits($row_cart_send['send_count']);

// Calculate the total number of products sold
$get_sell = "SELECT SUM(count) as total_sold FROM cart WHERE status='1'";
$run_sell = mysqli_query($con, $get_sell);
$row_sell = mysqli_fetch_array($run_sell);
$count_sell = convertToEnglishDigits($row_sell['total_sold'] ? $row_sell['total_sold'] : 0);

// Calculate the total gross income
$get_income = "SELECT SUM(cart.count * pro.price) as total_income FROM cart JOIN pro ON cart.pro_id = pro.id WHERE cart.status='1'";
$run_income = mysqli_query($con, $get_income);
$row_income = mysqli_fetch_array($run_income);
$total_income = number_format($row_income['total_income'] ? $row_income['total_income'] : 0, 2); // Handle NULL and format as currency
?>

<link rel="stylesheet" href="numbers.css">
<style>
    body, h4, p {
        font-family: 'Open Sans', sans-serif !important;
    }
    .price, .number {
        font-family: 'Open Sans', sans-serif !important;
    }
</style>

<div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- Total Users -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3 class="number"><?php echo $count_user; ?></h3>
                <p>Total Users</p>
              </div>
            </div>
          </div>

          <!-- Total Products -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h3 class="number"><?php echo $count_pro; ?></h3>
                <p>Total Products</p>
              </div>
            </div>
          </div>

          <!-- Unregistered User Carts -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <h3 class="number"><?php echo $count_uncart; ?></h3>
                <p>Unregistered User Carts</p>
              </div>
            </div>
          </div>

          <!-- Unpaid Carts -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
              <div class="inner">
                <h3 class="number"><?php echo $count_cart_nostatus; ?></h3>
                <p>Unpaid Carts</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Second row -->
        <div class="row">
          <!-- Carts Awaiting Shipment -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3 class="number"><?php echo $count_cart_unsend; ?></h3>
                <p>Carts Awaiting Shipment</p>
              </div>
            </div>
          </div>

          <!-- Shipped Carts -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h3 class="number"><?php echo $count_cart_send; ?></h3>
                <p>Shipped Carts</p>
              </div>
            </div>
          </div>

          <!-- Total Products Sold -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <h3 class="number"><?php echo $count_sell; ?></h3>
                <p>Total Products Sold</p>
              </div>
            </div>
          </div>

          <!-- Total Gross Income -->
          <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
              <div class="inner">
                <h3 class="number"><?php echo $total_income; ?></h3>
                <p>Total Gross Income</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
</div>
<script>
// Function to convert Persian numbers to English
function convertPersianNumbersToEnglish() {
    // Mapping Persian numbers to English numbers
    const persianToEnglishMap = {
        '۰': '0',
        '۱': '1',
        '۲': '2',
        '۳': '3',
        '۴': '4',
        '۵': '5',
        '۶': '6',
        '۷': '7',
        '۸': '8',
        '۹': '9'
    };

    // Convert numbers in the document
    document.body.innerHTML = document.body.innerHTML.replace(/[۰-۹]/g, function(match) {
        return persianToEnglishMap[match];
    });
}

// Run the conversion function on page load
window.onload = convertPersianNumbersToEnglish;
</script>
