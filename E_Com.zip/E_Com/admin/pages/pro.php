<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <title>Product List</title>
    
</head>
<body>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Products</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-left">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Products</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Product List</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Image</th>
                                <th>Price</th>
                                <th>Brand</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            // Database connection
                            $con = mysqli_connect("localhost", "root", "", "e_com");

                            // Check connection
                            if (!$con) {
                                die("Connection failed: " . mysqli_connect_error());
                            }

                            // Fetch products
                            $get = "SELECT * FROM pro";
                            $run = mysqli_query($con, $get);
                            while ($row = mysqli_fetch_array($run)) {
                                $id = $row['id'];
                                $name = $row['name'];
                                $img = $row['img'];
                                $price = $row['price']; // Assuming price is stored in English format
                                $cat_id = $row['cat_id'];

                                // Fetch category name
                                $get_cat = "SELECT * FROM cat WHERE id=$cat_id";
                                $run_cat = mysqli_query($con, $get_cat);
                                $row_cat = mysqli_fetch_array($run_cat);
                                $cat_name = $row_cat['name'];
                            ?>
                            <tr>
                                <td><a target="_blank" href="../pro.php?id=<?php echo($id); ?>"><?php echo(htmlspecialchars($name)); ?></a></td>
                                <td><img class="img-fluid" width="10%" src="../img/product/<?php echo(htmlspecialchars($img)); ?>" alt="Product Image" /></td>
                                <td class="price"><?php echo(number_format($price, 2)); ?></td> <!-- Format price to 2 decimal places -->
                                <td><?php echo(htmlspecialchars($cat_name)); ?></td>
                                <td><a class="btn" href="index.php?pro_edit&id=<?php echo($id); ?>">Edit</a></td>
                                <td><a class="btn btn-warning" href="index.php?pro_del&id=<?php echo($id); ?>">Delete</a></td>
                            </tr>
                            <?php 
                            } 
                            mysqli_close($con); // Close connection
                            ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<script>
// Function to convert Persian numbers to English
function convertPersianNumbersToEnglish() {
    // Mapping Persian numbers to English numbers
    const persianToEnglishMap = {
        '۰': '0',
        '۱': '1',
        '۲': '2',
        '۳': '3',
        '۴': '4',
        '۵': '5',
        '۶': '6',
        '۷': '7',
        '۸': '8',
        '۹': '9'
    };

    // Convert numbers in the document
    document.body.innerHTML = document.body.innerHTML.replace(/[۰-۹]/g, function(match) {
        return persianToEnglishMap[match];
    });
}

// Run the conversion function on page load
window.onload = convertPersianNumbersToEnglish;
</script>
</body>
</html>
