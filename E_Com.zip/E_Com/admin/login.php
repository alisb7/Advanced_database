<?php
session_start();
include('includes/db.php');
if (isset($_POST['submit'])) {
    if ($_POST['email'] != '' || $_POST['pass'] != '') {
        $email = $_POST['email'];
        $pass = md5($_POST['pass']);
        $get = "SELECT * FROM admin WHERE email='$email' AND pass='$pass'";
        $run = mysqli_query($con, $get);
        if (mysqli_num_rows($run) != 0) {
            $_SESSION['admin'] = $email;
            header('Location: index.php');
            exit(); // Always exit after a header redirect
        } else {
            echo "<script>alert('Invalid email or password.');</script>"; // Alert for invalid credentials
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin Panel | Login Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link rel="stylesheet" href="dist/css/custom-style.css">
    <style>
        body, h4, p {
            font-family: 'Open Sans', sans-serif !important;
        }
        .price {
            font-family: 'Open Sans', sans-serif !important;
        }
    </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="login-logo">
        <a href="index.php"><b>Login to Website</b></a>
    </div>
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Complete the form below and click Login</p>

            <form method="post">
                <div class="input-group mb-3">
                    <input type="email" class="form-control" placeholder="Email" name="email" required />
                    <div class="input-group-append">
                        <span class="fa fa-envelope input-group-text"></span>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" placeholder="Password" name="pass" required />
                    <div class="input-group-append">
                        <span class="fa fa-lock input-group-text"></span>
                    </div>
                </div>
                <div class="col-4">
                    <input type="submit" class="btn btn-primary btn-block btn-flat" name="submit" value="Login" />
                </div>
            </form>
            <br>
            <p>If you don’t have an account, <a href="seller_register.php">register here</a>.</p>
            <!-- Go Back to User Page Button -->
            <div class="col-4">
                <a href="../index.php" class="btn btn-secondary btn-block btn-flat"> User Page</a>
            </div>
        </div>
    </div>
</div>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass   : 'iradio_square-blue',
            increaseArea : '20%' // optional
        });
    });
</script>
</body>