<?php
session_start();
include('includes/db.php');

if (isset($_POST['register'])) {
    if ($_POST['username'] != '' && $_POST['password'] != '') {
        $username = $_POST['username'];
        $password = md5($_POST['password']); // Hash the password

        // Check if the username already exists
        $checkQuery = "SELECT * FROM admin WHERE email='$username'";
        $checkRun = mysqli_query($con, $checkQuery);

        if (mysqli_num_rows($checkRun) == 0) {
            // Insert the new user into the database
            $insertQuery = "INSERT INTO admin (email, pass) VALUES ('$username', '$password')";
            if (mysqli_query($con, $insertQuery)) {
                echo "<script>alert('Registration successful!'); window.location.href='login.php';</script>";
            } else {
                echo "<script>alert('Registration failed. Try again.');</script>";
            }
        } else {
            echo "<script>alert('Username already exists. Please choose another.');</script>";
        }
    } else {
        echo "<script>alert('Please fill all fields.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin Panel | Registration Page</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- Template RTL version -->
    <link rel="stylesheet" href="dist/css/custom-style.css">
    <style>
        body, h4, p {
            font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
        }
    </style>
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <div class="login-logo">
        <a href="index.php"><b>Register</b></a>
    </div>
    <!-- /.login-logo -->
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Complete the form below to register</p>

            <form method="post">
                <div class="input-group mb-3">
                    <input type="text" class="form-control" placeholder="Username" name="username" required />
                    <div class="input-group-append">
                        <span class="fa fa-user input-group-text"></span>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" class="form-control" placeholder="Password" name="password" required />
                    <div class="input-group-append">
                        <span class="fa fa-lock input-group-text"></span>
                    </div>
                </div>
                <div class="col-4">
                    <input type="submit" class="btn btn-primary btn-block btn-flat" name="register" value="Register" />
                </div>
                <!-- /.col -->
            </form>
            <br>
            <p>If you already have an account, <a href="login.php">login here</a>.</p> <!-- Link to login -->
            <!-- Go Back to User Page Button -->
            <div class="col-4">
                <a href="../index.php" class="btn btn-secondary btn-block btn-flat"> User Page</a>
            </div>
        </div>
        <!-- /.login-card-body -->
    </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass   : 'iradio_square-blue',
            increaseArea : '20%' // optional
        });
    });
</script>
</body>
</html>
