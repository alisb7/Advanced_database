<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: register.php');
    exit();
}
include('includes/db.php');

// Initialize variables
$email = $_SESSION['email'];
$user_id = $_SESSION['user_id']; // Assuming user_id is stored in session
$total = 0;

// Handle form submission for order confirmation
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Gather personal information
    $firstname = mysqli_real_escape_string($con, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($con, $_POST['lastname']);
    $telephone = mysqli_real_escape_string($con, $_POST['telephone']);
    $address_1 = mysqli_real_escape_string($con, $_POST['address_1']);
    $city = mysqli_real_escape_string($con, $_POST['city']);
    $postcode = mysqli_real_escape_string($con, $_POST['postcode']);

    // Insert into orders table
    $insert_order = "INSERT INTO orders (user_id, total_amount) VALUES ('$user_id', '$total')";
    if (mysqli_query($con, $insert_order)) {
        $order_id = mysqli_insert_id($con);

        // Insert order details
        $get_cart = "SELECT * FROM cart WHERE user_email='$email' AND status='0'";
        $run_cart = mysqli_query($con, $get_cart);
        
        while ($row_cart = mysqli_fetch_array($run_cart)) {
            $id = $row_cart['pro_id'];
            $count = $row_cart['count'];
            $get_pro_d = "SELECT * FROM pro WHERE id='$id'";
            $run_pro_d = mysqli_query($con, $get_pro_d);
            $row_pro_d = mysqli_fetch_array($run_pro_d);
            $price = $row_pro_d['price'];

            // Insert order details
            $insert_order_details = "INSERT INTO order_details (order_id, product_id, quantity, price) VALUES ('$order_id', '$id', '$count', '$price')";
            mysqli_query($con, $insert_order_details);

            // Calculate total
            $total += $price * $count;
        }

        // Update total amount in orders table
        mysqli_query($con, "UPDATE orders SET total_amount = '$total' WHERE id = '$order_id'");
        
        // Clear cart
        mysqli_query($con, "DELETE FROM cart WHERE user_email='$email' AND status='0'");

        // Set success message in session
        $_SESSION['order_success'] = "Order placed successfully!";

        // Redirect to order page
        header("Location: order.php?id=$order_id");
        exit();
    }
}
?>

<!DOCTYPE html>
<html dir="ltr">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link href="image/favicon.png" rel="icon" />
    <title>Checkout - Online Mobile Store</title>
    <link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
    <link rel="stylesheet" type="text/css" href="css/responsive.css" />
    <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans' type='text/css'>
    <style>
        body, h4, p {
            font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
        }
        .price {
            font-family: 'Open Sans', sans-serif !important; /* Ensures price uses default font */
        }
    </style>
</head>
<body>
<div class="wrapper-wide">
    <div id="header">
        <?php include('includes/header.php'); ?>
    </div>
    <div id="container">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-home"></i></a></li>
                <li><a href="cart.php">Shopping Cart</a></li>
                <li><a href="checkout.php">Checkout</a></li>
            </ul>
            <div class="row">
                <div id="content" class="col-sm-12">
                    <h1 class="title">Checkout</h1>
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><i class="fa fa-user"></i> Your Personal Information</h4>
                                    </div>
                                    <div class="panel-body">
                                        <fieldset id="account">
                                            <div class="form-group required">
                                                <label for="input-payment-firstname" class="control-label">First Name</label>
                                                <input type="text" class="form-control" id="input-payment-firstname" name="firstname" required>
                                            </div>
                                            <div class="form-group required">
                                                <label for="input-payment-lastname" class="control-label">Last Name</label>
                                                <input type="text" class="form-control" id="input-payment-lastname" name="lastname" required>
                                            </div>
                                            <div class="form-group required">
                                                <label for="input-payment-email" class="control-label">Email Address</label>
                                                <input type="email" class="form-control" id="input-payment-email" name="email" value="<?php echo $email; ?>" readonly>
                                            </div>
                                            <div class="form-group required">
                                                <label for="input-payment-telephone" class="control-label">Telephone Number</label>
                                                <input type="text" class="form-control" id="input-payment-telephone" name="telephone" required>
                                            </div>
                                        </fieldset>
                                        <fieldset id="address">
                                            <div class="form-group required">
                                                <label for="input-payment-address-1" class="control-label">Address 1</label>
                                                <input type="text" class="form-control" id="input-payment-address-1" name="address_1" required>
                                            </div>
                                            <div class="form-group required">
                                                <label for="input-payment-city" class="control-label">City</label>
                                                <input type="text" class="form-control" id="input-payment-city" name="city" required>
                                            </div>
                                            <div class="form-group required">
                                                <label for="input-payment-postcode" class="control-label">Postcode</label>
                                                <input type="text" class="form-control" id="input-payment-postcode" name="postcode" required>
                                            </div>
                                        </fieldset>
                                        <div class="buttons clearfix">
                                            <div class="pull-right">
                                                <input type="submit" class="btn btn-primary" value="Confirm Order">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-8">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <h4 class="panel-title"><i class="fa fa-shopping-cart"></i> Shopping Cart</h4>
                                    </div>
                                    <div class="panel-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <td class="text-center">Image</td>
                                                        <td class="text-left">Product Name</td>
                                                        <td class="text-left">Quantity</td>
                                                        <td class="text-right">Unit Price</td>
                                                        <td class="text-right">Total</td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $get_cart = "SELECT * FROM cart WHERE user_email='$email' AND status='0'";
                                                    $run_cart = mysqli_query($con, $get_cart);
                                                    while ($row_cart = mysqli_fetch_array($run_cart)) {
                                                        $id = $row_cart['pro_id'];
                                                        $count = $row_cart['count'];
                                                        $get_pro_d = "SELECT * FROM pro WHERE id='$id'";
                                                        $run_pro_d = mysqli_query($con, $get_pro_d);
                                                        $row_pro_d = mysqli_fetch_array($run_pro_d);
                                                        $name = $row_pro_d['name'];
                                                        $img = $row_pro_d['img'];
                                                        $price = $row_pro_d['price'];
                                                        $total += $price * $count;
                                                        ?>
                                                        <tr>
                                                            <td class="text-center"><a href="pro.php?id=<?php echo($id); ?>"><img src="img/product/<?php echo($img); ?>" width="20%" class="img-thumbnail" /></a></td>
                                                            <td class="text-left"><a href="pro.php?id=<?php echo($id); ?>"><?php echo($name); ?></a></td>
                                                            <td class="text-left"><?php echo($count); ?></td>
                                                            <td class="text-right"><?php echo number_format($price, 2); ?> AUD</td>
                                                            <td class="text-right"><?php echo number_format($price * $count, 2); ?> AUD</td>
                                                        </tr>
                                                    <?php } ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="4" class="text-right">Total:</td>
                                                        <td class="text-right"><?php echo number_format($total, 2); ?> AUD</td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php'); ?>
</div>
<script src="js/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap/js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/theme.js"></script>
</body>
</html>
