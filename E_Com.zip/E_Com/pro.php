<?php
include('includes/db.php');

// Fetch all products
$get_products = "SELECT * FROM pro"; // Fetch all products
$run_products = mysqli_query($con, $get_products);
if (!$run_products) {
    die("Query failed: " . mysqli_error($con));
}

$products = [];
while ($row_product = mysqli_fetch_array($run_products)) {
    $products[] = $row_product; // Store all products
}

// Fetch all categories for the dropdown
$categories = [];
$get_categories = "SELECT * FROM cat";
$run_categories = mysqli_query($con, $get_categories);
if (!$run_categories) {
    die("Query failed: " . mysqli_error($con));
}
while ($row_category = mysqli_fetch_array($run_categories)) {
    $categories[] = $row_category;
}

// Sorting logic (if needed for product listing)
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'name_asc';
$order_by = 'name ASC';

switch ($sort) {
    case 'name_asc':
        $order_by = 'name ASC';
        break;
    case 'name_desc':
        $order_by = 'name DESC';
        break;
    case 'price_asc':
        $order_by = 'price ASC';
        break;
    case 'price_desc':
        $order_by = 'price DESC';
        break;
}

// Sort products based on selected order
usort($products, function($a, $b) use ($order_by) {
    if ($order_by === 'name ASC') {
        return strcmp($a['name'], $b['name']);
    } elseif ($order_by === 'name DESC') {
        return strcmp($b['name'], $a['name']);
    } elseif ($order_by === 'price ASC') {
        return $a['price'] - $b['price'];
    } else {
        return $b['price'] - $a['price'];
    }
});
?>

<!DOCTYPE html>
<html dir="ltr">
<head>
<meta charset="UTF-8" />
<meta name="format-detection" content="telephone=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="image/favicon.png" rel="icon" />
<title>All Products</title>
<meta name="description" content="Responsive and clean HTML template design for any kind of eCommerce webshop">
<link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
<link rel="stylesheet" type="text/css" href="js/swipebox/src/css/swipebox.min.css">
<link rel="stylesheet" type="text/css" href="css/responsive.css" />
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans' type='text/css'>
<style>
    body, h4, p {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
    .price {
        font-family: 'Open Sans', sans-serif !important; /* Ensures price uses default font */
    }
</style>
</head>
<body>
<div class="wrapper-wide">
  <div id="header">
    <?php include('includes/header.php'); ?>
  </div>
  <div id="container">
    <div class="container">
      <div class="row">
        <!--Middle Part Start-->
        <div id="content" class="col-sm-9">
          <h1>All Products</h1>
          <div class="row">
            <?php foreach ($products as $product): ?>
              <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="product-item">
                  <div class="image"><img src="img/product/<?php echo $product['img']; ?>" alt="<?php echo $product['name']; ?>" class="img-responsive" /></div>
                  <h4 class="name"><a href="pro.php?id=<?php echo $product['id']; ?>"><?php echo $product['name']; ?></a></h4>
                  <p class="price"><?php echo $product['price']; ?> USD</p>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
        <!--Middle Part End -->
        <!--Right Part Start -->
        <aside id="column-right" class="col-sm-3 hidden-xs">
          <h3>Sort by</h3>
          <ul>
            <li><a href="?sort=name_asc">Name A-Z</a></li>
            <li><a href="?sort=name_desc">Name Z-A</a></li>
            <li><a href="?sort=price_asc">Price Low to High</a></li>
            <li><a href="?sort=price_desc">Price High to Low</a></li>
          </ul>
          <h3>Categories</h3>
          <ul>
            <?php foreach ($categories as $category): ?>
              <li><a href="cat.php?cat=<?php echo htmlspecialchars($category['name']); ?>"><?php echo htmlspecialchars($category['name']); ?></a></li>
            <?php endforeach; ?>
          </ul>
        </aside>
        <!--Right Part End -->
      </div>
    </div>
  </div>
  <?php include('includes/footer.php'); ?>
</div>
<script src="js/jquery/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap/js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery/swipebox.min.js"></script>
<script src="js/template.js"></script>
</body>
</html>
