<?php
$db_host = 'localhost';
$db_username = 'root';
$db_password = ''; // No password
$db_name = 'e_com'; 

$con = mysqli_connect($db_host, $db_username, $db_password, $db_name);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset to UTF-8
mysqli_set_charset($con, 'utf8');
?>
