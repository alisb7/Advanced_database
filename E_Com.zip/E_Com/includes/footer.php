<footer id="footer">
    <div class="fpart-first">
        <div class="container">
            <div class="row">
                <div class="contact col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <h5>Contact Information</h5>
                    <ul>
                        <li class="address"><i class="fa fa-map-marker"></i>2/516 Railway Parade, Sydney, Australia</li>
                        <li class="mobile"><i class="fa fa-phone"></i>0450566965</li>
                        <li class="email"><i class="fa fa-envelope"></i>Contact us via <a href="contact-us.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
                    <h5>Information</h5>
                    <ul>
                        <li><a href="about-us.php">About Us</a></li>
                        <li><a href="shipping-information.php">Shipping Information</a></li>
                        <li><a href="privacy-policy.php">Privacy Policy</a></li>
                        <li><a href="terms-and-conditions.php">Terms and Conditions</a></li>
                    </ul>
                </div>
                <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
                    <h5>Customer Service</h5>
                    <ul>
                        <li><a href="contact-us.php">Contact Us</a></li>
                        <li><a href="returns.php">Returns</a></li>
                        <li><a href="sitemap.php">Site Map</a></li>
                    </ul>
                </div>
                <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
                    <h5>Additional Features</h5>
                    <ul>
                        <li><a href="brands.php">Brands</a></li>
                        <li><a href="gift-cards.php">Gift Cards</a></li>
                        <li><a href="special-offers.php">Special Offers</a></li>
                        <li><a href="loyalty-program.php">Loyalty Program</a></li>
                    </ul>
                </div>
                <div class="column col-lg-2 col-md-2 col-sm-3 col-xs-12">
                    <h5>My Account</h5>
                    <ul>
                        <li><a href="account.php">Account</a></li>
                        <li><a href="order-history.php">Order History</a></li>
                        <li><a href="wishlist.php">Wishlist</a></li>
                        <li><a href="newsletter.php">Newsletter</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="fpart-second">
        <div class="container">
            <div class="bottom-row">
                <div class="custom-text text-center">
                <p>Welcome to our e-commerce platform! We provide a wide range of products at competitive prices. Explore our collections and enjoy a seamless shopping experience.</p>
                <p>&copy; 2024 Online Electronics. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
    <div id="back-top"><a data-toggle="tooltip" title="Back to top" href="javascript:void(0)" class="backtotop"><i class="fa fa-chevron-up"></i></a></div>
</footer>
