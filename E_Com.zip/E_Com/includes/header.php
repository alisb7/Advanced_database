<?php 
include('db.php');
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

include('func/get_ip.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles.css">
    <title>Electronics Stores</title>
    <style>
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            background-color: #fff;
            border: 1px solid #ccc;
            z-index: 1000;
            min-width: 160px;
        }

        .dropdown:hover .dropdown-menu {
            display: block;
        }

        .dropdown-menu a {
            display: block;
            padding: 10px;
            text-decoration: none;
            color: black;
        }

        .dropdown-menu a:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>

<nav id="top" class="htop">
  <div class="container">
    <div class="row">
      <span class="drop-icon visible-sm visible-xs"><i class="fa fa-align-justify"></i></span>
      <div class="pull-left flip left-top"></div>
      <div id="top-links" class="nav pull-right flip">
        <?php if(isset($_SESSION['email'])) { ?>
        <ul>
          <li><a href="logout.php">Logout</a></li>
          <li><a href="profile.php">Hello, <?php echo htmlspecialchars($_SESSION['email']); ?></a></li>
        <?php } else { ?>
        <ul>
          <li><a href="login.php">Login</a></li>
          <li><a href="register.php">Register</a></li>
          <li><a href="admin/login.php">Seller Login</a></li> 
        </ul>
        <?php } ?>
      </div>
    </div>
  </div>
</nav>
<!-- Header Start-->
<header class="header-row">
  <div class="container">
    <div class="table-container">
      <div class="col-table-cell col-lg-6 col-md-6 col-sm-12 col-xs-12 inner">
        <div id="logo"><a href="index.php"><h1>Electronics Stores</h1></a></div>
      </div>
      <div class="col-table-cell col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div id="cart">
          <button type="button" data-toggle="dropdown" class="heading dropdown-toggle">
          <span class="cart-icon pull-left flip"></span>
          <?php
          $count_cart = 0;
          $total = 0;
          if(isset($_SESSION['email'])){
            $email = $_SESSION['email'];
            $get_mini = "SELECT * FROM cart WHERE user_email='$email' AND status='0'";
            $run_mini = mysqli_query($con, $get_mini);
          } else {
            $ip = getUserIP();
            $get_mini = "SELECT * FROM uncart WHERE ip='$ip'";
            $run_mini = mysqli_query($con, $get_mini);
          }
          while($row_mini = mysqli_fetch_array($run_mini)){
            $pro_id_mini = $row_mini['pro_id'];
            $count = $row_mini['count'];
            $get_detail = "SELECT * FROM pro WHERE id=$pro_id_mini";
            $run_detail = mysqli_query($con, $get_detail);
            $row_detail = mysqli_fetch_array($run_detail);
            $price = $row_detail['price'];
            $count_cart += $count;
            $total += ($price * $count);
          }
          ?>
          <span id="cart-total"><?php echo($count_cart); ?> Items Totaling <?php echo($total); ?> AUD</span></button>
          <ul class="dropdown-menu">
            <li>
              <table class="table">
                <tbody>
                  <?php
                  if(isset($_SESSION['email'])){
                    $email = $_SESSION['email'];
                    $get_mini = "SELECT * FROM cart WHERE user_email='$email' AND status='0'";
                    $run_mini = mysqli_query($con, $get_mini);
                  } else {
                    $ip = getUserIP();
                    $get_mini = "SELECT * FROM uncart WHERE ip='$ip'";
                    $run_mini = mysqli_query($con, $get_mini);
                  }
                  while($row_mini = mysqli_fetch_array($run_mini)){
                    $pro_id_mini = $row_mini['pro_id'];
                    $count = $row_mini['count'];
                    $get_detail = "SELECT * FROM pro WHERE id=$pro_id_mini";
                    $run_detail = mysqli_query($con, $get_detail);
                    $row_detail = mysqli_fetch_array($run_detail);
                    $price = $row_detail['price'];
                    $name = $row_detail['name'];
                    $img = $row_detail['img']; ?>
                      <tr>
                        <td class="text-center"><a href="pro.php?id=<?php echo($pro_id_mini); ?>"><img class="img-thumbnail" src="img/product/<?php echo($img); ?>"></a></td>
                        <td class="text-left"><a href="pro.php?id=<?php echo($pro_id_mini); ?>"><?php echo($name); ?></a></td>
                        <td class="text-right">x <?php echo($count); ?></td>
                        <td class="text-right"><?php echo($price * $count); ?> AUD</td>
                        <td class="text-center"><form method="POST" action="func/del_cart.php"><input type="hidden" name='id' value="<?php echo($pro_id_mini); ?>" /><input type="submit" name='submit' class="btn btn-danger btn-xs remove" value='Remove' /></form></td>
                      </tr>
                    <?php } ?>
                </tbody>
              </table>
            </li>
            <li>
              <div>
                <table class="table table-bordered">
                  <tbody>
                    <tr>
                      <td class="text-right"><strong>Total</strong></td>
                      <td class="text-right"><?php echo($total); ?> </td>
                    </tr>
                  </tbody>
                </table>
                <p class="checkout"><a href="cart.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> View Cart</a>&nbsp;&nbsp;&nbsp;<a href="checkout.php" class="btn btn-primary"><i class="fa fa-share"></i> Checkout</a></p>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div class="col-table-cell col-lg-3 col-md-3 col-sm-6 col-xs-12 inner">
        <div id="search" class="input-group">
          <input id="filter_name" type="text" name="search" value="" placeholder="Search Products" class="form-control input-lg" />
          <button type="button" class="button-search"><i class="fa fa-search"></i></button>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- Header End-->

<!-- Main Menu Start-->
<div class="container">
  <nav id="menu" class="navbar">
    <div class="navbar-header"> <span class="visible-xs visible-sm"> Menu <b></b></span></div>
    <div class="collapse navbar-collapse navbar-ex1-collapse">
      <ul class="nav navbar-nav">
        <li><a class="home_link" title="Home" href="index.php"><span>Home</span></a></li>
        <li><a title="Products" href="pro.php"><span>Products</span></a></li>
        <li><a title="Order" href="order.php"><span>Order</span></a></li>
        <li><a title="Cart" href="cart.php"><span>Cart</span></a></li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle">Sort By</a>
          <ul class="dropdown-menu">
          <li><a href="pro.php?sort=price_low">Price: Low to High</a></li>
          <li><a href="pro.php?sort=price_high">Price: High to Low</a></li>
          <li><a href="pro.php?sort=alphabetical">Alphabetical Order</a></li>

          </ul>
        </li>
        <li class="mega-menu dropdown">
          <a href="#" class="dropdown-toggle">Categories</a>
          <div class="dropdown-menu">
            <div>
              <ul>
                <?php
                $get_cat_h = "SELECT * FROM cat";
                $run_cat_h = mysqli_query($con, $get_cat_h);
                while($row_cat_h = mysqli_fetch_array($run_cat_h)){
                    $cat_id = $row_cat_h['id'];
                    $cat_name = $row_cat_h['name']; ?>
                    <li><a href="cat.php?cat=<?php echo urlencode($cat_name); ?>"><?php echo htmlspecialchars($cat_name); ?></a></li>
                <?php } ?>
              </ul>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </nav>
</div>
<!-- Main Menu End-->

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var dropdowns = document.querySelectorAll('.dropdown');

    dropdowns.forEach(function(dropdown) {
      dropdown.addEventListener('click', function(e) {
        e.stopPropagation();
        var menu = this.querySelector('.dropdown-menu');
        menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
      });
    });

    document.addEventListener('click', function() {
      dropdowns.forEach(function(dropdown) {
        var menu = dropdown.querySelector('.dropdown-menu');
        menu.style.display = 'none';
      });
    });
  });
</script>

</body>
</html>
