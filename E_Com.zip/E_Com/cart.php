<?php
include('includes/db.php');
session_start();
?>
<!DOCTYPE html>
<html dir="ltr">
<head>
<meta charset="UTF-8" />
<meta name="format-detection" content="telephone=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="image/favicon.png" rel="icon" />
<title>Shopping Cart</title>
<meta name="description" content="Responsive and clean HTML template design for any kind of eCommerce webshop">
<!-- CSS Part Start-->
<link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css" />
<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" />
<link rel="stylesheet" type="text/css" href="css/owl.transitions.css" />
<link rel="stylesheet" type="text/css" href="css/responsive.css" />
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans' type='text/css'>
<style>
    body, h4, p, .price {
        font-family: 'Open Sans', sans-serif !important; /* Default font for all text */
    }
</style>
<!-- CSS Part End-->
</head>
<body>
<div class="wrapper-wide">
  <div id="header">
    <!-- Top Bar Start-->
    <?php include('includes/header.php'); ?>
    <!-- Main Content End-->
  </div>
  <div id="container">
    <div class="container">
      <!-- Breadcrumb Start-->
      <ul class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-home"></i></a></li>
        <li><a href="cart.php">Shopping Cart</a></li>
      </ul>
      <!-- Breadcrumb End-->
      <div class="row">
        <!-- Middle Part Start-->
        <div id="content" class="col-sm-12">
          <h1 class="title">Shopping Cart</h1>
            <div class="table-responsive">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <td class="text-center">Image</td>
                    <td class="text-left">Product Name</td>
                    <td class="text-left">Quantity</td>
                    <td class="text-right">Unit Price</td>
                    <td class="text-right">Total</td>
                    <td class="text-right">Action</td>
                  </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;

                    if(isset($_SESSION['email'])){
                      $email = $_SESSION['email'];
                      $get_cart = "SELECT * FROM cart WHERE user_email='$email' AND status='0'";
                    } else {
                      $ip = getUserIP(); // Ensure getUserIP() function is defined in your code
                      $get_cart = "SELECT * FROM uncart WHERE ip='$ip'";
                    }
                    
                    $run_cart = mysqli_query($con, $get_cart);
                    
                    while($row_cart = mysqli_fetch_array($run_cart)){
                      $id = $row_cart['pro_id'];
                      $count = $row_cart['count'];

                      $get_pro_d = "SELECT * FROM pro WHERE id=$id";
                      $run_pro_d = mysqli_query($con, $get_pro_d);
                      $row_pro_d = mysqli_fetch_array($run_pro_d);
                      $name = $row_pro_d['name'];
                      $img = $row_pro_d['img'];
                      $price = $row_pro_d['price'];
                      $total += ($price * $count);
                      ?>
                      <tr>
                        <td class="text-center"><a href="pro.php?id=<?php echo($id); ?>"><img src="img/product/<?php echo($img); ?>" width="20%" class="img-thumbnail" /></a></td>
                        <td class="text-left"><a href="pro.php?id=<?php echo($id); ?>"><?php echo($name); ?></a></td>
                        <td class="text-left">
                          <div class="input-group btn-block quantity">
                            <input type="number" name="count" value="<?php echo($count); ?>" size="1" class="form-control" min="1" />
                            <span class="input-group-btn">
                              <form method="POST" action="func/update_cart.php">
                                <input type="hidden" name='id' value="<?php echo($id); ?>" />
                                <input type="submit" class="btn btn-primary btn-xs" value='Update' />
                              </form>
                            </span>
                          </div>
                        </td>
                        <td class="text-right"><?php echo($price); ?> USD</td>
                        <td class="text-right"><?php echo($price * $count); ?> USD</td>
                        <td class="text-right">
                          <form method="POST" action="func/del_cart.php">
                            <input type="hidden" name='id' value="<?php echo($id); ?>" />
                            <input type="submit" name='submit' class="btn btn-danger btn-xs" value='Remove' />
                          </form>
                        </td>
                      </tr>
                    <?php } ?>
                </tbody>
              </table>
            </div>
          <h2 class="subtitle">What would you like to do next?</h2>

          <div class="row">
            <div class="col-sm-4 col-sm-offset-8">
              <table class="table table-bordered">
                <tr>
                  <td class="text-right"><strong>Total:</strong></td>
                  <td class="text-right"><?php echo($total); ?> USD</td>
                </tr>
              </table>
            </div>
          </div>
          <div class="buttons">
            <div class="pull-left"><a href="index.php" class="btn btn-default">Continue Shopping</a></div>
            <div class="pull-right"><a href="checkout.php" class="btn btn-primary">Checkout</a></div>
          </div>
        </div>
        <!-- Middle Part End -->
      </div>
    </div>
  </div>
  <!-- Footer Start-->
  <?php include('includes/footer.php'); ?>
  <!-- Footer End-->
  
</div>
<!-- JS Part Start-->
<script type="text/javascript" src="js/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.easing-1.3.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/custom.js"></script>
<!-- JS Part End-->
</body>
</html>
