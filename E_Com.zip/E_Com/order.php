<?php
session_start();
include('includes/db.php');

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: register.php');
    exit();
}

// Fetch all orders for the logged-in user
$user_id = $_SESSION['user_id'];
$stmt = $con->prepare("SELECT id, order_date, total_amount, status FROM orders WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html dir="ltr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>My Orders</title>
    <link rel="stylesheet" type="text/css" href="js/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
        }
    </style>
</head>
<body>
<div class="wrapper-wide">
    <div id="header">
        <?php include('includes/header.php'); ?>
    </div>
    <div id="container">
        <div class="container">
            <h1 class="title">My Orders</h1>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Order Date</th>
                        <th>Total Amount</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($order = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($order['id']) . "</td>";
                            echo "<td>" . htmlspecialchars($order['order_date']) . "</td>";
                            echo "<td>" . number_format($order['total_amount'], 2) . " AUD</td>";
                            echo "<td>" . htmlspecialchars($order['status']) . "</td>";
                            echo "<td><a href='order_details.php?id=" . $order['id'] . "' class='btn btn-info'>View Details</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No orders found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <a href="cart.php" class="btn btn-primary">Back to Cart</a>
        </div>
    </div>
    <footer id="footer">
        <?php include('includes/footer.php'); ?>
    </footer>
</div>
<script src="js/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Close the statement
$stmt->close();
?>
