<?php
session_start();
include('includes/db.php');
include('func/add_uncart_cart.php');

// Initialize variables
$email = '';
$password = '';
$loginError = false;

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Validate form inputs
    if (empty($_POST['email']) || empty($_POST['password'])) {
        $loginError = true; // Display error if any field is empty
    } else {
        $email = trim($_POST['email']);
        $password = $_POST['password']; // Plain text password (not hashed yet)

        // Prepare the SQL statement
        $stmt = $con->prepare("SELECT * FROM user WHERE Email = ?");
        
        // Check if the statement was prepared successfully
        if ($stmt) {
            // Bind parameters (s means string type)
            $stmt->bind_param("s", $email);

            // Execute the prepared statement
            $stmt->execute();

            // Get the result
            $result = $stmt->get_result();

            // Check if the user exists
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();

                // Verify the password
                if (password_verify($password, $user['Password'])) {
                    // After successful login
                    $_SESSION['email'] = $user['Email'];
                    $_SESSION['user_id'] = $user['UserID']; // Assuming you have a UserID field

                    // Debugging output (temporary for testing)
                    // echo "Logged in successfully as: " . $_SESSION['email'];

                    // Add uncarted items to cart (optional function)
                    add_uncart_cart();

                    // Redirect to the profile page
                    header('Location: profile.php');
                    exit();
                } else {
                    $loginError = true; // Invalid password
                }
            } else {
                $loginError = true; // User not found
            }

            // Close the statement
            $stmt->close();
        } else {
            // If the statement preparation fails, handle the error
            die('MySQL prepare() failed: ' . htmlspecialchars($con->error));
        }
    }
}
?>

<!DOCTYPE html>
<html dir="ltr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Login</title>
    <!-- Include external CSS files -->
    <link rel="stylesheet" href="js/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/stylesheet.css" />
    <link rel="stylesheet" href="css/responsive.css" />
</head>
<body>
<div class="wrapper-wide">
    <div id="header">
        <?php include('includes/header.php'); ?>
    </div>
    
    <div id="container">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="index.php"><i class="fa fa-home"></i></a></li>
                <li><a href="login.php">Account</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
            
            <div class="row">
                <div id="content" class="col-sm-9">
                    <h1 class="title">Account Login</h1>
                    <div class="row">
                        <div class="col-sm-6">
                            <h2 class="subtitle">New Customer</h2>
                            <p><strong>Create an Account</strong></p>
                            <p>By creating an account, you will be able to shop faster, keep track of your orders, and view your order history.</p>
                            <a href="register.php" class="btn btn-primary">Continue</a>
                        </div>
                        
                        <div class="col-sm-6">
                            <h2 class="subtitle">Returning Customer</h2>
                            <form method="POST">
                                <p><strong>I am a returning customer</strong></p>
                                
                                <div class="form-group">
                                    <label class="control-label" for="input-email">Email Address</label>
                                    <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" placeholder="Email Address" id="input-email" class="form-control" required />
                                </div>
                                
                                <div class="form-group">
                                    <label class="control-label" for="input-password">Password</label>
                                    <input type="password" name="password" value="" placeholder="Password" id="input-password" class="form-control" required />
                                </div>
                                
                                <div class="form-group">
                                    <input type="submit" value="Login" class="btn btn-primary" name="submit" />
                                </div>
                            </form>

                            <!-- Display error message if login failed -->
                            <?php if ($loginError): ?>
                                <div class="alert alert-danger">Invalid email or password.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include('includes/footer.php'); ?>
</div>

<!-- Include external JavaScript files -->
<script src="js/jquery-2.1.1.min.js"></script>
<script src="js/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
